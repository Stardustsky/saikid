/* 存档层：schema 版本、旧档迁移、防抖写入、异常兜底、导入导出 */
const SaveStore = (() => {
  const KEY = 'xiaolongmao_save';
  const LEGACY_KEYS = ['saikid_save', 'saikid_save_v1'];
  const APP_ID = 'xiaolongmao';
  const VERSION = 2;
  const WRITE_DELAY = 320;

  let timer = null;
  let pending = null;
  let available = probe();

  function probe() {
    try {
      const k = '__saikid_probe__';
      localStorage.setItem(k, '1');
      localStorage.removeItem(k);
      return true;
    } catch (e) {
      return false;
    }
  }

  function readRaw() {
    if (!available) return null;
    try {
      const own = localStorage.getItem(KEY);
      if (own) return own;
      // 兼容改名前的旧存档（saikid_save / saikid_save_v1）
      for (const k of LEGACY_KEYS) {
        const old = localStorage.getItem(k);
        if (old) return old;
      }
      return null;
    } catch (e) {
      available = false;
      return null;
    }
  }

  function clearLegacy() {
    try {
      LEGACY_KEYS.forEach(k => {
        if (localStorage.getItem(k)) localStorage.removeItem(k);
      });
    } catch (e) { /* 忽略 */ }
  }

  function writeNow(state) {
    if (!available || !state) return false;
    try {
      localStorage.setItem(KEY, JSON.stringify(state));
      clearLegacy();
      return true;
    } catch (e) {
      // 配额不足或无痕模式：降级为仅本次会话有效
      available = false;
      return false;
    }
  }

  function migrate(data) {
    if (!data || typeof data !== 'object') return null;
    const v = Number(data.version) || 1;
    // v1 -> v2：新增闯关进度、每日任务、引导标记，交给 normalize 补齐字段
    if (v < VERSION) data.version = VERSION;
    return data;
  }

  function load(normalize) {
    let parsed = null;
    const raw = readRaw();
    if (raw) {
      try { parsed = JSON.parse(raw); } catch (e) { parsed = null; }
    }
    return normalize(migrate(parsed));
  }

  function save(state) {
    pending = state;
    clearTimeout(timer);
    timer = setTimeout(() => {
      timer = null;
      if (pending) writeNow(pending);
      pending = null;
    }, WRITE_DELAY);
  }

  function flush() {
    clearTimeout(timer);
    timer = null;
    if (pending) {
      writeNow(pending);
      pending = null;
    }
  }

  function reset() {
    clearTimeout(timer);
    pending = null;
    try {
      localStorage.removeItem(KEY);
      clearLegacy();
    } catch (e) { /* 忽略 */ }
  }

  function usage() {
    try {
      let raw = localStorage.getItem(KEY) || '';
      if (!raw) {
        for (const k of LEGACY_KEYS) raw = raw || localStorage.getItem(k) || '';
      }
      return raw.length;
    } catch (e) {
      return 0;
    }
  }

  function exportText(state) {
    return JSON.stringify({
      app: APP_ID,
      version: VERSION,
      exportedAt: new Date().toISOString(),
      state: state
    }, null, 2);
  }

  function importText(text, normalize) {
    let parsed = null;
    try { parsed = JSON.parse(text); } catch (e) {
      return { ok: false, error: '不是有效的存档文件' };
    }
    const legacy = parsed && parsed.app === 'saikid';
    const src = parsed && (parsed.app === APP_ID || legacy) ? parsed.state : parsed;
    if (!src || typeof src !== 'object' || Array.isArray(src)) {
      return { ok: false, error: '存档内容不完整' };
    }
    return { ok: true, state: normalize(migrate(src)) };
  }

  window.addEventListener('pagehide', flush);
  window.addEventListener('beforeunload', flush);
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'hidden') flush();
  });

  return {
    VERSION,
    load,
    save,
    flush,
    reset,
    usage,
    exportText,
    importText,
    isAvailable: () => available
  };
})();

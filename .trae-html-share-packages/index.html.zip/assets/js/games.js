/* 六大学科的游戏引擎：按「阶段」出题，从认识 → 练习 → 综合 */
const Game = (() => {
  // 学科元信息直接来自课程体系，保证首页、关卡、家长中心一致
  const SUBJECTS = {};
  Object.keys(DATA.curriculum).forEach(k => {
    const c = DATA.curriculum[k];
    SUBJECTS[k] = { key: k, name: c.name, icon: c.icon, color: c.color, tag: c.tag };
  });

  const STAGE_TOTAL = 6;   // 阶段练习每题数少一点，幼儿更容易完成
  const MAP_TOTAL = 8;     // 闯关模式
  const PRAISE = ['太棒啦！', '答对啦！', '真聪明！', '好厉害！', '完全正确！', '你真棒！'];

  let session = null;
  let locked = false;
  let mainTimer = null;
  let advanceTimer = null;

  const $ = sel => document.querySelector(sel);
  const rnd = (a, b) => a + Math.floor(Math.random() * (b - a + 1));
  const pick = arr => arr[Math.floor(Math.random() * arr.length)];
  const shuffle = arr => {
    const r = arr.slice();
    for (let i = r.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [r[i], r[j]] = [r[j], r[i]];
    }
    return r;
  };
  const normOpt = x => (x && typeof x === 'object' ? Object.assign({}, x) : { label: String(x) });
  const pic = s => Art.em(s);
  const makeOptions = (correct, wrongs) => shuffle([
    Object.assign(normOpt(correct), { correct: true }),
    ...wrongs.map(w => Object.assign(normOpt(w), { correct: false }))
  ]);

  function say(holder) {
    if (!holder) return;
    if (Array.isArray(holder)) AudioFX.speakSegments(holder);
    else AudioFX.speak(holder.text, holder.lang, holder.audio);
  }

  function findStage(subjectKey, stageId) {
    const c = DATA.curriculum[subjectKey];
    if (!c) return null;
    const st = c.stages.find(s => s.id === stageId);
    return st ? Object.assign({ subject: subjectKey }, st) : null;
  }

  /* ---------- 取题池 ---------- */

  function poolWords(st) {
    return st.theme && st.theme !== 'all'
      ? DATA.words.filter(w => w.theme === st.theme)
      : DATA.words.slice();
  }

  function poolHanzi(st) {
    return st.cat && st.cat !== 'all'
      ? DATA.hanzi.filter(h => h.cat === st.cat)
      : DATA.hanzi.slice();
  }

  function poolLetters(st) {
    const r = st.range || [0, DATA.letters.length - 1];
    return DATA.letters.slice(r[0], r[1] + 1);
  }

  function uniqueLabels(list, key, exclude) {
    const seen = new Set(exclude ? [exclude] : []);
    return list.filter(x => {
      if (seen.has(x[key])) return false;
      seen.add(x[key]);
      return true;
    });
  }

  /* ---------- 数字乐园 ---------- */

  function qCount(st) {
    const max = st.max || 10;
    const min = st.min || 1;
    const n = rnd(min, max);
    const emoji = pick(DATA.countEmojis);
    const wrong = new Set();
    let guard = 0;
    while (wrong.size < 3 && guard++ < 60) {
      const c = rnd(1, Math.min(12, max + 2));
      if (c !== n) wrong.add(c);
    }
    const items = Array.from({ length: n }, (_, i) =>
      `<span style="animation-delay:${i * 70}ms">${pic(emoji)}</span>`).join('');
    return {
      key: 'n-count-' + n + emoji,
      title: '数一数，一共有几个呀？',
      visual: `<div class="count-grid">${items}</div>`,
      speak: { text: '数一数，一共有几个呀？', lang: 'zh-CN' },
      speakAnswer: { text: String(n), lang: 'zh-CN' },
      options: makeOptions(String(n), [...wrong].map(String)),
      hint: '用小手指着，一个一个慢慢数～'
    };
  }

  function qQuantity(st) {
    const max = Math.min(6, st.max || 6);
    const min = st.min || 1;
    const n = rnd(min, max);
    const emoji = pick(DATA.countEmojis);
    const wrong = [];
    while (wrong.length < 3) {
      const c = rnd(1, 6);
      if (c !== n && !wrong.includes(c)) wrong.push(c);
    }
    return {
      key: 'n-qty-' + n + emoji,
      title: '哪个盘子里正好有 ' + n + ' 个？',
      visual: `<div class="digit-big">${n}</div>`,
      speak: { text: '哪个盘子里正好有 ' + n + ' 个？', lang: 'zh-CN' },
      speakAnswer: { text: '这里有 ' + n + ' 个', lang: 'zh-CN' },
      options: makeOptions(
        { label: emoji.repeat(n), html: `<span class="mini-count">${pic(emoji.repeat(n))}</span>` },
        wrong.map(c => ({ label: emoji.repeat(c), html: `<span class="mini-count">${pic(emoji.repeat(c))}</span>` }))
      ),
      hint: `数一数，${n} 个就是 ${n} 个哦～`
    };
  }

  function qNext(st) {
    const max = st.max || 10;
    const start = rnd(1, Math.max(1, max - 3));
    const seq = [start, start + 1, start + 2];
    const answer = start + 3;
    const wrong = new Set();
    let guard = 0;
    while (wrong.size < 3 && guard++ < 60) {
      const c = rnd(1, max + 1);
      if (c !== answer) wrong.add(c);
    }
    return {
      key: 'n-next-' + answer,
      title: '接下来是哪个数字呢？',
      visual: `<div class="seq">${seq.map(n => `<span>${n}</span>`).join('')}<span class="seq-q">?</span></div>`,
      speak: { text: '接下来是哪个数字呢？', lang: 'zh-CN' },
      speakAnswer: { text: String(answer), lang: 'zh-CN' },
      options: makeOptions(String(answer), [...wrong].map(String)),
      hint: '后面的数字，总比前面的大 1 哦～'
    };
  }

  function qCompare(st) {
    const max = st.max || 10;
    let a = rnd(2, max);
    let b = rnd(1, max);
    let guard = 0;
    while (a === b && guard++ < 30) b = rnd(1, max);
    if (a === b) b = a === max ? a - 1 : a + 1;
    const bigger = a > b;
    const wrong = new Set();
    while (wrong.size < 2) {
      const c = rnd(1, max + 1);
      if (c !== a && c !== b) wrong.add(c);
    }
    return {
      key: 'n-cmp-' + a + '-' + b,
      title: '哪个数字更大？',
      visual: `<div class="seq compare"><span>${a}</span><span class="vs">和</span><span>${b}</span></div>`,
      speak: { text: `${a} 和 ${b}，哪个数字更大？`, lang: 'zh-CN' },
      speakAnswer: { text: `更大的数字是 ${bigger ? a : b}`, lang: 'zh-CN' },
      options: makeOptions(String(bigger ? a : b), [String(bigger ? b : a), ...[...wrong].map(String)]),
      hint: '数字越大，就排在越后面哦～'
    };
  }

  function qPattern(st) {
    const max = st.max || 10;
    const step = Math.random() < 0.65 ? 1 : 2;
    const start = rnd(1, Math.max(1, max - step * 3));
    const seq = [start, start + step, start + step * 2];
    const answer = start + step * 3;
    const wrong = new Set();
    let guard = 0;
    while (wrong.size < 3 && guard++ < 60) {
      const c = Math.max(1, answer + rnd(-4, 4));
      if (c !== answer) wrong.add(c);
    }
    return {
      key: 'n-pat-' + start + '-' + step,
      title: '找规律，接下来是几？',
      visual: `<div class="seq">${seq.map(n => `<span>${n}</span>`).join('')}<span class="seq-q">?</span></div>`,
      speak: { text: '找一找规律，接下来是哪个数字？', lang: 'zh-CN' },
      speakAnswer: { text: String(answer), lang: 'zh-CN' },
      options: makeOptions(String(answer), [...wrong].map(String)),
      hint: step === 1
        ? '每次都多 1，接着数下去就好啦～'
        : '每次都多 2，看看能发现吗？'
    };
  }

  /* ---------- 字母王国 ---------- */

  function qLetterListen(st) {
    const pool = poolLetters(st);
    const item = pick(pool);
    const wrong = shuffle(uniqueLabels(pool, 'u', item.u)).slice(0, 3).map(x => x.u);
    return {
      key: 'l-listen-' + item.u,
      title: '听一听，是哪个字母？',
      visual: `<div class="sound-orb">🔊</div><div class="visual-note">点喇叭可以再听一遍</div>`,
      speak: { text: item.u, lang: 'en-US' },
      speakAnswer: { text: item.u, lang: 'en-US' },
      options: makeOptions(item.u, wrong.length ? wrong : ['X', 'Y', 'Z']),
      hint: '字母 ' + item.u + ' 就像「' + item.zh + '」的 ' + item.word + ' 开头～'
    };
  }

  function qLetterCase(st) {
    const pool = poolLetters(st);
    const item = pick(pool);
    const wrong = shuffle(uniqueLabels(pool, 'l', item.l)).slice(0, 3).map(x => x.l);
    const askLower = Math.random() < 0.6;
    if (askLower) {
      return {
        key: 'l-caseL-' + item.u,
        title: '它的小写字母是哪个？',
        visual: `<div class="big-letter">${item.u}</div><div class="letter-hint">${pic(item.emoji)} ${item.word} · ${item.zh}</div>`,
        speak: { text: item.u, lang: 'en-US' },
        speakAnswer: { text: item.l, lang: 'en-US' },
        options: makeOptions(item.l, wrong.length ? wrong : ['x', 'y', 'z']),
        hint: '大写 ' + item.u + '，小写 ' + item.l + ' 长得像它的缩小版～'
      };
    }
    const wrongU = shuffle(uniqueLabels(pool, 'u', item.u)).slice(0, 3).map(x => x.u);
    return {
      key: 'l-caseU-' + item.u,
      title: '它的大写字母是哪个？',
      visual: `<div class="big-letter lower">${item.l}</div><div class="letter-hint">${pic(item.emoji)} ${item.word} · ${item.zh}</div>`,
      speak: { text: item.l, lang: 'en-US' },
      speakAnswer: { text: item.u, lang: 'en-US' },
      options: makeOptions(item.u, wrongU.length ? wrongU : ['X', 'Y', 'Z']),
      hint: '小写 ' + item.l + '，大写就是 ' + item.u + '～'
    };
  }

  function qLetterOrder(st) {
    const pool = poolLetters(st);
    const idx = rnd(0, Math.max(0, pool.length - 3));
    const seq = [pool[idx], pool[idx + 1]];
    const answer = pool[idx + 2].u;
    const wrong = shuffle(DATA.letters.filter(x => x.u !== answer)).slice(0, 3).map(x => x.u);
    return {
      key: 'l-next-' + answer,
      title: '字母排队，接下来是谁？',
      visual: `<div class="seq">${seq.map(x => `<span>${x.u}</span>`).join('')}<span class="seq-q">?</span></div>`,
      speak: [{ text: seq[0].u, lang: 'en-US' }, { text: seq[1].u, lang: 'en-US' }],
      speakAnswer: { text: answer, lang: 'en-US' },
      options: makeOptions(answer, wrong),
      hint: '一起唱字母歌：A B C D E F G…'
    };
  }

  /* ---------- 单词花园 ---------- */

  function qWordPic(st) {
    const pool = poolWords(st);
    const item = pick(pool);
    const wrong = shuffle(pool.filter(x => x.en !== item.en)).slice(0, 3).map(x => x.en);
    return {
      key: 'w-en-' + item.en,
      title: '这个用英语怎么说？',
      visual: `<div class="big-emoji">${pic(item.emoji)}</div><div class="visual-note">${item.zh}</div>`,
      speak: { text: item.zh, lang: 'zh-CN' },
      speakAnswer: { text: item.en, lang: 'en-US' },
      options: makeOptions(item.en, wrong),
      hint: '跟我读：' + item.en
    };
  }

  function qWordListen(st) {
    const pool = poolWords(st);
    const item = pick(pool);
    const wrong = shuffle(pool.filter(x => x.en !== item.en)).slice(0, 3);
    return {
      key: 'w-listen-' + item.en,
      title: '听一听，是哪个？',
      visual: `<div class="sound-orb">🔊</div><div class="visual-note">点喇叭可以再听一遍</div>`,
      speak: { text: item.en, lang: 'en-US' },
      speakAnswer: { text: item.en, lang: 'en-US' },
      options: makeOptions(
        { label: item.zh, html: `<span class="opt-pic">${pic(item.emoji)}</span><span class="opt-sub">${item.zh}</span>` },
        wrong.map(x => ({ label: x.zh, html: `<span class="opt-pic">${pic(x.emoji)}</span><span class="opt-sub">${x.zh}</span>` }))
      ),
      hint: item.en + ' 就是「' + item.zh + '」～'
    };
  }

  function qWordMeaning(st) {
    const pool = poolWords(st);
    const item = pick(pool);
    const wrong = shuffle(pool.filter(x => x.emoji !== item.emoji)).slice(0, 3);
    return {
      key: 'w-zh-' + item.en,
      title: '这个单词是什么意思？',
      visual: `<div class="word-big">${item.en}</div><div class="visual-note">听一听，选出正确的图片</div>`,
      speak: { text: item.en, lang: 'en-US' },
      speakAnswer: { text: item.en, lang: 'en-US' },
      options: makeOptions(
        { label: item.zh, html: `<span class="opt-pic">${pic(item.emoji)}</span><span class="opt-sub">${item.zh}</span>` },
        wrong.map(x => ({ label: x.zh, html: `<span class="opt-pic">${pic(x.emoji)}</span><span class="opt-sub">${x.zh}</span>` }))
      ),
      hint: item.en + ' 就是「' + item.zh + '」的意思～'
    };
  }

  /* ---------- 算术工坊 ---------- */

  function qMath(st, force) {
    const max = st.max || 10;
    const mode = force || pick(st.qtypes);
    const isSub = mode === 'sub';
    let a, b, answer;

    if (isSub) {
      a = rnd(2, max);
      b = rnd(1, a - 1);
      answer = a - b;
    } else {
      a = rnd(1, max - 1);
      b = rnd(1, max - a);
      answer = a + b;
    }

    const wrong = new Set();
    let guard = 0;
    while (wrong.size < 3 && guard++ < 60) {
      const c = Math.max(0, answer + rnd(-4, 4));
      if (c !== answer && c <= max + 2) wrong.add(c);
    }

    let dots = '';
    if (a <= 10 && b <= 10) {
      const dotA = Array.from({ length: a }, () => '<i class="dot"></i>').join('');
      if (isSub) {
        const keep = Array.from({ length: a - b }, () => '<i class="dot"></i>').join('');
        const gone = Array.from({ length: b }, () => '<i class="dot dot-gone"></i>').join('');
        dots = `<div class="dots">${keep}${gone}</div>`;
      } else {
        const dotB = Array.from({ length: b }, () => '<i class="dot dot-b"></i>').join('');
        dots = `<div class="dots">${dotA}<span class="dot-plus">+</span>${dotB}</div>`;
      }
    }

    return {
      key: 'm-' + a + (isSub ? '-' : '+') + b,
      title: '算一算，等于几？',
      visual: `<div class="equation">${a} ${isSub ? '−' : '+'} ${b} = <span class="eq-q">?</span></div>${dots}`,
      speak: { text: `${a} ${isSub ? '减' : '加'} ${b} 等于几？`, lang: 'zh-CN' },
      speakAnswer: { text: `等于 ${answer}`, lang: 'zh-CN' },
      options: makeOptions(String(answer), [...wrong].map(String)),
      hint: isSub ? '从 ' + a + ' 个里拿走 ' + b + ' 个，剩下几个呢？' : a + ' 个加上 ' + b + ' 个，一起数一数～'
    };
  }

  /* ---------- 拼音小路 ---------- */

  function qPyInitial(st) {
    const all = DATA.pinyin.initials;
    const g = st.group || [0, all.length - 1];
    const pool = all.slice(g[0], g[1] + 1);
    const item = pick(pool);
    const wrong = shuffle(all.filter(x => x.p !== item.p)).slice(0, 3).map(x => x.p);
    return {
      key: 'py-ini-' + item.p,
      title: '听一听，它的声母是哪个？',
      visual: `<div class="big-emoji">${pic(item.emoji)}</div><div class="visual-note">${item.word}</div>`,
      speak: { text: item.word, lang: 'zh-CN' },
      speakAnswer: { text: item.word, lang: 'zh-CN' },
      options: makeOptions(item.p, wrong),
      hint: '「' + item.word + '」开头的声母是 ' + item.p
    };
  }

  function qPyFinal(st) {
    const all = DATA.pinyin.finals;
    const item = pick(all);
    const wrong = shuffle(all.filter(x => x.p !== item.p)).slice(0, 3).map(x => x.p);
    return {
      key: 'py-fin-' + item.p,
      title: '听一听，它的韵母是哪个？',
      visual: `<div class="big-emoji">${pic(item.emoji)}</div><div class="visual-note">${item.word}</div>`,
      speak: { text: item.word, lang: 'zh-CN' },
      speakAnswer: { text: item.word, lang: 'zh-CN' },
      options: makeOptions(item.p, wrong.length ? wrong : ['a', 'o', 'e']),
      hint: '「' + item.word + '」的韵母是 ' + item.p
    };
  }

  function qPySyllable(st) {
    const pool = DATA.pinyin.syllables;
    const item = pick(pool);
    const wrong = shuffle(pool.filter(x => x.c !== item.c)).slice(0, 3).map(x => x.c);
    return {
      key: 'py-syl-' + item.p,
      title: '拼一拼，读出来是哪个字？',
      visual: `<div class="pinyin-big">${item.p}</div><div class="big-emoji small">${pic(item.emoji)}</div>`,
      speak: { text: item.c, lang: 'zh-CN', audio: AudioFX.pyAudio.yinjie(item.p) },
      speakAnswer: { text: item.c, lang: 'zh-CN', audio: AudioFX.pyAudio.yinjie(item.p) },
      options: makeOptions(item.c, wrong),
      hint: '拼一拼 ' + item.p + '，就是「' + item.c + '」'
    };
  }

  function qPyTone(st) {
    const pool = DATA.pinyin.syllables.filter(x => x.tone);
    const item = pick(pool);
    const TONES = ['一声 ˉ', '二声 ˊ', '三声 ˇ', '四声 ˋ'];
    return {
      key: 'py-tone-' + item.p,
      title: '这个音是第几声？',
      visual: `<div class="pinyin-big">${item.p}</div><div class="big-hanzi small">${item.c}</div><div class="visual-note">${pic(item.emoji)} ${item.c}</div>`,
      speak: { text: item.c, lang: 'zh-CN', audio: AudioFX.pyAudio.yinjie(item.p) },
      speakAnswer: { text: item.c, lang: 'zh-CN', audio: AudioFX.pyAudio.yinjie(item.p) },
      options: makeOptions(TONES[item.tone - 1], TONES.filter((_, i) => i !== item.tone - 1)),
      hint: '一声平、二声扬、三声拐弯、四声降'
    };
  }

  function qPyChar(st) {
    const pool = poolHanzi(st);
    const item = pick(pool);
    const wrong = shuffle(pool.filter(x => x.p !== item.p)).slice(0, 3).map(x => x.p);
    return {
      key: 'py-char-' + item.c,
      title: '这个字的拼音是哪个？',
      visual: `<div class="big-hanzi">${item.c}</div><div class="visual-note">${pic(item.emoji)} ${item.word}</div>`,
      speak: { text: item.c, lang: 'zh-CN' },
      speakAnswer: { text: item.c, lang: 'zh-CN' },
      options: makeOptions(item.p, wrong.length ? wrong : ['mā', 'bā', 'dà']),
      hint: '它读作 ' + item.p + '，跟着读一读～'
    };
  }

  /* ---------- 汉字森林 ---------- */

  function qHzPic(st) {
    const pool = poolHanzi(st);
    const item = pick(pool);
    const wrong = shuffle(pool.filter(x => x.c !== item.c && x.emoji !== item.emoji)).slice(0, 3).map(x => x.c);
    return {
      key: 'h-char-' + item.c,
      title: '这是什么字？',
      visual: `<div class="big-emoji">${pic(item.emoji)}</div><div class="visual-note">${item.word}</div>`,
      speak: { text: item.word, lang: 'zh-CN' },
      speakAnswer: { text: item.c, lang: 'zh-CN' },
      options: makeOptions(item.c, wrong.length ? wrong : ['山', '水', '火']),
      hint: '「' + item.word + '」的「' + item.c + '」，读作 ' + item.p
    };
  }

  function qHzMeaning(st) {
    const pool = poolHanzi(st);
    const item = pick(pool);
    const wrong = shuffle(pool.filter(x => x.c !== item.c && x.emoji !== item.emoji)).slice(0, 3);
    return {
      key: 'h-pic-' + item.c,
      title: '这个字是什么东西？',
      visual: `<div class="big-hanzi">${item.c}</div><div class="pinyin-small">${item.p}</div>`,
      speak: { text: item.c, lang: 'zh-CN' },
      speakAnswer: { text: item.c, lang: 'zh-CN' },
      options: makeOptions(
        { label: item.word, html: `<span class="opt-pic">${pic(item.emoji)}</span><span class="opt-sub">${item.word}</span>` },
        wrong.map(x => ({ label: x.word, html: `<span class="opt-pic">${pic(x.emoji)}</span><span class="opt-sub">${x.word}</span>` }))
      ),
      hint: item.c + ' 就是「' + item.word + '」～'
    };
  }

  function qHzListen(st) {
    const pool = poolHanzi(st);
    const item = pick(pool);
    const wrong = shuffle(pool.filter(x => x.c !== item.c)).slice(0, 3).map(x => x.c);
    return {
      key: 'h-listen-' + item.c,
      title: '听一听，是哪个字？',
      visual: `<div class="sound-orb">🔊</div><div class="visual-note">点喇叭可以再听一遍</div>`,
      speak: { text: item.word, lang: 'zh-CN' },
      speakAnswer: { text: item.c, lang: 'zh-CN' },
      options: makeOptions(item.c, wrong),
      hint: '「' + item.word + '」写成一个字就是 ' + item.c
    };
  }

  const BUILDERS = {
    count: qCount,
    quantity: qQuantity,
    next: qNext,
    compare: qCompare,
    pattern: qPattern,
    letterListen: qLetterListen,
    letterCase: qLetterCase,
    letterOrder: qLetterOrder,
    wordPic: qWordPic,
    wordListen: qWordListen,
    wordMeaning: qWordMeaning,
    add: st => qMath(st, 'add'),
    sub: st => qMath(st, 'sub'),
    pyInitial: qPyInitial,
    pyFinal: qPyFinal,
    pySyllable: qPySyllable,
    pyTone: qPyTone,
    pyChar: qPyChar,
    hzPic: qHzPic,
    hzMeaning: qHzMeaning,
    hzListen: qHzListen
  };

  /* ---------- 会话流程 ---------- */

  // stageId：课程阶段；levelId：闯关关卡（0 表示自由练习）
  function start(subjectKey, stageId, levelId) {
    const st = findStage(subjectKey, stageId);
    if (!st) return;
    App.maybeGuide(subjectKey, () => begin(st, levelId || 0));
  }

  function startStage(subjectKey, stageId) {
    start(subjectKey, stageId, 0);
  }

  function begin(stage, levelId) {
    AudioFX.unlock();
    const total = levelId ? MAP_TOTAL : STAGE_TOTAL;
    const questions = [];
    const seen = new Set();

    for (let i = 0; i < total; i++) {
      let q = null;
      let guard = 0;
      do {
        const type = pick(stage.qtypes);
        const builder = BUILDERS[type];
        q = builder ? builder(stage) : null;
        guard++;
      } while ((!q || seen.has(q.key)) && guard < 30);
      if (q) {
        seen.add(q.key);
        questions.push(q);
      }
    }

    session = {
      key: stage.subject,
      subject: SUBJECTS[stage.subject],
      stage,
      stageId: stage.id,
      levelId: levelId || 0,
      index: 0,
      correct: 0,
      combo: 0,
      bestCombo: 0,
      questions
    };
    locked = false;
    App.markDay();

    const head = $('#stage-name');
    if (head) head.textContent = stage.name;
    App.show('game');
    renderQuestion();
  }

  function renderQuestion() {
    const q = session.questions[session.index];
    if (!q) return finish();

    locked = false;
    const card = $('#q-card');
    card.classList.remove('shake');
    $('#q-title').textContent = q.title;
    $('#q-visual').innerHTML = q.visual;
    $('#game-progress-fill').style.width = (session.index / session.questions.length * 100) + '%';
    $('#game-combo').innerHTML = session.combo >= 2 ? `<span>连对 ${session.combo} 🔥</span>` : '';
    $('#game-tip').textContent = '';
    $('#game-tip').className = 'game-tip';

    const wrap = $('#options');
    wrap.innerHTML = '';
    q.options.forEach((o, i) => {
      const b = document.createElement('button');
      b.className = 'option';
      b.style.animationDelay = (i * 55) + 'ms';
      b.innerHTML = o.html || `<span class="opt-text">${o.label}</span>`;
      b.addEventListener('click', () => answer(b, o));
      wrap.appendChild(b);
    });

    const listen = $('#btn-listen');
    listen.classList.toggle('show', !!q.speak);

    clearTimeout(mainTimer);
    if (q.speak) {
      AudioFX.preload(q.speak);
      mainTimer = setTimeout(() => say(q.speak), 420);
    }
    if (q.speakAnswer) AudioFX.preload(q.speakAnswer);
  }

  function answer(btn, opt) {
    if (locked || !session) return;
    locked = true;
    clearTimeout(mainTimer);
    AudioFX.unlock();

    const q = session.questions[session.index];
    const buttons = [...document.querySelectorAll('.option')];
    buttons.forEach(b => b.classList.add('disabled'));

    if (opt.correct) {
      btn.classList.add('correct');
      session.correct++;
      session.combo++;
      session.bestCombo = Math.max(session.bestCombo, session.combo);
      AudioFX.correct();
      burst(btn);
      showTip(pick(PRAISE), 'good');
      advanceTimer = setTimeout(nextQuestion, 1150);
    } else {
      btn.classList.add('wrong');
      const correctIndex = q.options.findIndex(o => o.correct);
      if (buttons[correctIndex]) buttons[correctIndex].classList.add('correct');
      session.combo = 0;
      AudioFX.wrong();
      $('#q-card').classList.add('shake');
      showTip(q.hint || '没关系，看看正确答案吧～', 'bad');
      advanceTimer = setTimeout(nextQuestion, 1900);
    }

    $('#game-score').textContent = '✅ ' + session.correct;
    $('#game-combo').innerHTML = session.combo >= 2 ? `<span>连对 ${session.combo} 🔥</span>` : '';

    if (q.speakAnswer) setTimeout(() => say(q.speakAnswer), 280);
  }

  function nextQuestion() {
    if (!session) return;
    session.index++;
    if (session.index >= session.questions.length) finish();
    else renderQuestion();
  }

  function finish() {
    if (!session) return;
    clearTimeout(mainTimer);
    clearTimeout(advanceTimer);
    AudioFX.stopSpeak();

    const total = session.questions.length;
    const accuracy = session.correct / total;
    const need = session.levelId ? Math.ceil(total * 0.6) : Math.ceil(total * 0.6);
    const passed = session.correct >= need;
    const stars = session.correct === total ? 3 : accuracy >= 0.8 ? 2 : passed ? 1 : 0;

    const result = App.finishSession({
      subject: session.key,
      correct: session.correct,
      total,
      bestCombo: session.bestCombo,
      stars,
      levelId: session.levelId,
      stageId: session.stageId
    });

    const level = result.level;
    const stage = result.stage;
    const shownStars = Math.max(0, stars);

    $('#game-progress-fill').style.width = '100%';
    $('#result-stars').innerHTML = [1, 2, 3].map(i =>
      `<span class="rstar ${i <= shownStars ? 'on' : ''}" style="animation-delay:${i * 160}ms">⭐</span>`).join('');

    $('#result-title').textContent = passed
      ? (stars === 3 ? '完美通关！' : '闯关成功！')
      : '还差一点点～';
    $('#result-sub').textContent = passed
      ? (stars === 3
        ? '全部答对，小龙猫为你骄傲～'
        : '成功过关啦，再来一次挑战满星吧！')
      : `答对 ${need} 题就能过关，你答对了 ${session.correct} 题，再挑战一次吧！`;

    if (level) {
      $('#result-level').innerHTML = level.passed
        ? `<span class="rlv ok">🗺️ 第 ${level.id} 关 · ${level.name} · 最佳 ${level.stars} 星</span>`
        : `<span class="rlv fail">🗺️ 第 ${level.id} 关 · ${level.name} · 差 ${level.need - session.correct} 题</span>`;
    } else if (stage) {
      $('#result-level').innerHTML = passed
        ? `<span class="rlv ok">${stage.icon} ${stage.name} · 最佳 ${stage.stars} 星</span>`
        : `<span class="rlv fail">${stage.icon} ${stage.name} · 再试一次吧</span>`;
    } else {
      $('#result-level').innerHTML = '';
    }

    $('#result-stats').innerHTML = `
      <div class="rstat"><b>${session.correct}<i>/${total}</i></b><span>答对题数</span></div>
      <div class="rstat"><b>${session.bestCombo}</b><span>最高连对</span></div>
      <div class="rstat"><b>${Math.round(accuracy * 100)}%</b><span>正确率</span></div>`;

    $('#result-rewards').innerHTML = `
      <div class="reward">🌰 <b>+${result.coins}</b> 橡果币</div>
      <div class="reward">💗 <b>+${result.exp}</b> 成长值</div>
      ${level && level.newClear ? '<div class="reward newclear">🗺️ 首次通关 <b>+20</b> 橡果币</div>' : ''}
      ${stage && stage.newClear ? '<div class="reward newclear">🎯 首次完成 <b>+10</b> 橡果币</div>' : ''}
      ${result.leveledUp ? '<div class="reward levelup">🎉 小龙猫升级啦！</div>' : ''}`;

    const backBtn = $('#btn-back-map');
    if (backBtn) backBtn.textContent = session.levelId ? '回到地图' : '返回关卡';

    AudioFX.levelUp();
    App.show('result');
    App.refreshHud();
  }

  function showTip(text, type) {
    const el = $('#game-tip');
    if (!el) return;
    el.textContent = text;
    el.className = 'game-tip show ' + (type || '');
  }

  function cleanup() {
    clearTimeout(mainTimer);
    clearTimeout(advanceTimer);
    AudioFX.stopSpeak();
    session = null;
    locked = false;
  }

  function quit() {
    const wasLevel = session && session.levelId;
    const key = session && session.key;
    cleanup();
    if (wasLevel) App.show('map');
    else if (key) App.showStages(key);
    else App.show('home');
  }

  function replay() {
    if (!session) return;
    const key = session.key;
    const stageId = session.stageId;
    const levelId = session.levelId;
    start(key, stageId, levelId);
  }

  function listen() {
    if (!session) return;
    const q = session.questions[session.index];
    if (q && q.speak) say(q.speak);
  }

  /* 星星粒子 */
  function burst(el) {
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const layer = document.getElementById('fx-layer');
    if (!layer) return;
    const chars = ['⭐', '✨', '🌟', '💫', '🎉'];
    for (let i = 0; i < 9; i++) {
      const s = document.createElement('span');
      s.className = 'spark';
      s.textContent = pick(chars);
      s.style.left = (rect.left + rect.width / 2) + 'px';
      s.style.top = (rect.top + rect.height / 2) + 'px';
      const ang = Math.random() * Math.PI * 2;
      const dist = 45 + Math.random() * 80;
      s.style.setProperty('--dx', Math.cos(ang) * dist + 'px');
      s.style.setProperty('--dy', Math.sin(ang) * dist - 50 + 'px');
      s.style.fontSize = (16 + Math.random() * 18) + 'px';
      layer.appendChild(s);
      setTimeout(() => s.remove(), 950);
    }
  }

  return {
    SUBJECTS,
    start,
    startStage,
    quit,
    replay,
    listen,
    burst,
    cleanup,
    info: () => (session ? { subject: session.key, stageId: session.stageId, levelId: session.levelId } : null)
  };
})();

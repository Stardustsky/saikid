/* 插画素材：用本地 Twemoji SVG 替换 emoji，跨设备显示一致，也更有儿童绘本的感觉 */
const Art = (() => {
  // 与 assets/img/emoji 文件名一致：小写十六进制、去掉变体选择符、保留 ZWJ
  const RE = /[\u{1F000}-\u{1FAFF}\u{2600}-\u{27BF}\u{2B00}-\u{2BFF}]\uFE0F?(?:\u200D[\u{1F000}-\u{1FAFF}\u2600-\u27BF]\uFE0F?)*/gu;

  function key(emoji) {
    return [...String(emoji)]
      .map(c => c.codePointAt(0))
      .filter(cp => cp !== 0xfe0f)
      .map(cp => cp.toString(16))
      .join('-');
  }

  function img(name, ch) {
    return `<img class="em" src="assets/img/emoji/${name}.svg" alt="${ch}" draggable="false">`;
  }

  // 把字符串里的 emoji 换成插画，其余字符原样保留
  function em(text) {
    const s = text == null ? '' : String(text);
    if (!s) return '';
    return s.replace(RE, m => (EMOJI_SET.has(key(m)) ? img(key(m), m) : m));
  }

  return { em, key };
})();
